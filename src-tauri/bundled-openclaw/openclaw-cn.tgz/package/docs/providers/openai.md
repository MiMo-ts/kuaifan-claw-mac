---
summary: "Use OpenAI via API keys or Codex subscription in Clawdbot"
read_when:
  - You want to use OpenAI models in Clawdbot
  - You want Codex subscription auth instead of API keys
---
# OpenAI

OpenAI provides developer APIs for GPT models. Codex supports **ChatGPT sign-in** for subscription
access or **API key** sign-in for usage-based access. Codex cloud requires ChatGPT sign-in, while
the Codex CLI supports either sign-in method. The Codex CLI caches login details in
`~/.codex/auth.json` (or your OS credential store), which Clawdbot can reuse.

## Option A: OpenAI API key (OpenAI Platform)

**Best for:** direct API access and usage-based billing.
Get your API key from the OpenAI dashboard.

### CLI setup

```bash
openclaw-cn onboard --auth-choice openai-api-key
# or non-interactive
openclaw-cn onboard --openai-api-key "$OPENAI_API_KEY"
```

### Config snippet

```json5
{
  env: { OPENAI_API_KEY: "sk-..." },
  agents: { defaults: { model: { primary: "openai/gpt-5.2" } } }
}
```

## Option B: OpenAI Code (Codex) subscription

**Best for:** using ChatGPT/Codex subscription access instead of an API key.
Codex cloud requires ChatGPT sign-in, while the Codex CLI supports ChatGPT or API key sign-in.

Clawdbot can reuse your **Codex CLI** login (`~/.codex/auth.json`) or run the OAuth flow.

### CLI setup

```bash
# Reuse existing Codex CLI login
openclaw-cn onboard --auth-choice codex-cli

# Or run Codex OAuth in the wizard
openclaw-cn onboard --auth-choice openai-codex
```

### Config snippet

```json5
{
  agents: { defaults: { model: { primary: "openai-codex/gpt-5.2" } } }
}
```

## Notes

- Model refs always use `provider/model` (see [/concepts/models](/concepts/models)).
- Auth details + reuse rules are in [/concepts/oauth](/concepts/oauth).
